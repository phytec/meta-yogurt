
i2c function for to change camera-sensor registers


use of this function only possible, if camera-interface-driver is loaded (MCLK activ)
./i2c -?

example: read camera-ID
./i2c -a 0x48 -d /dev/[dev or subdev-number] -r 0x00
./i2c -a 0x48 -d /dev/v4l-subdev5 -r 0x00 (i.MX6 Quad)

