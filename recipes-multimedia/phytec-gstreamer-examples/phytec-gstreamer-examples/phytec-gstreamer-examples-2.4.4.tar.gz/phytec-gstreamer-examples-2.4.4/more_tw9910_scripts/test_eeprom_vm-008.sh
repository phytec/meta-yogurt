#!/bin/sh

# i2c Bus number: 0 = phyCARD-S, 2 = phyCARD-M, phyFLEX-i.MX6, phyCOR-i.MX6 1 = phyCARD-L, phyCARD-i.MX6
I2CBUS_NUMBER=2

echo
echo "read EEPROM(Bank 0) at VM-008"
echo "============================="
echo "read Reg 0x00"
i2cget -y $I2CBUS_NUMBER 0x52 0x00
echo "write Reg 0x00 value 0x55 and read back"
i2cset -y $I2CBUS_NUMBER 0x52 0x00 0x55
i2cget -y $I2CBUS_NUMBER 0x52 0x00
echo "write Reg 0x00 value 0xFF (default) and read back"
i2cset -y $I2CBUS_NUMBER 0x52 0x00 0xFF
i2cget -y $I2CBUS_NUMBER 0x52 0x00


echo
echo "read EEPROM(Bank 1) at VM-008"
echo "============================="
echo "read Reg 0x00"
i2cget -y $I2CBUS_NUMBER 0x53 0x00
echo "write Reg 0x00 value 0xAA and read back"
i2cset -y $I2CBUS_NUMBER 0x53 0x00 0xAA
i2cget -y $I2CBUS_NUMBER 0x53 0x00
echo "write Reg 0x00 value 0xFF (default) and read back"
i2cset -y $I2CBUS_NUMBER 0x53 0x00 0xFF
i2cget -y $I2CBUS_NUMBER 0x53 0x00

