#!/bin/sh

# i2c Bus number: 0 = phyCARD-S, 2 = phyCARD-M, phyFLEX-i.MX6, phyCOR-i.MX6 1 = phyCARD-L, phyCARD-i.MX6
I2CBUS_NUMBER=2

echo
echo "test LEDs at VM-008"
echo "==================="
echo "set all ports output"
i2cset -y $I2CBUS_NUMBER 0x70 0x03 0x00
echo "set red LEDs"
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0x55
sleep 1
echo "set green LEDs"
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0xaa
sleep 1
echo "set all LEDs"
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0x00
sleep 1
echo "set LEDs separate"
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0xff
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0xfe
sleep 1
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0xfb
sleep 1
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0xef
sleep 1
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0xbf
sleep 1
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0x7f
sleep 1
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0xdf
sleep 1
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0xf7
sleep 1
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0xfd
sleep 1
i2cset -y $I2CBUS_NUMBER 0x70 0x01 0x00
sleep 1

i2cset -y $I2CBUS_NUMBER 0x70 0x01 0xFF
echo "set all ports input (default)"
i2cset -y $I2CBUS_NUMBER 0x70 0x03 0xFF

