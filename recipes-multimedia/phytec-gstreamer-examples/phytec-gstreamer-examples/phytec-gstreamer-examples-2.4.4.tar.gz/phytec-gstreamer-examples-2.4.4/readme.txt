**********************************************************
The following informations are for the PHYTEC BSP PD16.1.0
/ phyFLEX-i.MX6 / phyCARD-i.MX6 / phyCORE-i.MX6
**********************************************************

The following phytec cameras are currently supported:
(depend on hardware interface phyCAM-P and/or phyCAM-S+ on board)
- VM-006 (@43,2MHz use "master-clock_vm006_vm009.sh") Note: contact Phytec for right pixel polarity		
- VM-006-LVDS (@36MHz use "master-clock_vm006_vm009.sh")
- VM-008 (interlaced, only halfframes)
- VM-009 (@54MHz use "master-clock_vm006_vm009.sh")		
- VM-009-LVDS (@36MHz use "master-clock_vm006_vm009.sh")
- VM-010-BW (@27MHz)
- VM-010-COL (@27MHz)
- VM-010-BW-LVDS (@27MHz)
- VM-010-COL-LVDS (@27MHz)
- VM-011-BW (@54MHz)
- VM-011-COL (@54MHz)
- VM-011-BW-LVDS (@54MHz)
- VM-011-COL-LVDS (@54MHz)
- VM-012-BW (@54MHz)
- VM-012-COL (@54MHz)
- VM-012-BW-LVDS (@54MHz)
- VM-012-COL-LVDS (@54MHz)

For USB-cameras look into "\phytec_usb_cam\..." path.

Additional phytec camera support is in progress.

Please pay attention to the maximum allowable frequencies.
Please read the the Manual L-740 "phyCAM-P / phyCAM-S".


********************************************************************
camera configuration
********************************************************************

The i.MX6 moduls comes with one ore two port for phyCAM-S+ or phyCAM-P cameras on
i.MX6 CSIx interface. The right camera-interface-type, camera-type and camera-address
must be set, by bootarg in the config-file (/env/config-expansions). 

- phyFLEX-i.MX6 with CSO0 and CSI1 as parallel or LVDS
  * phyFLEX-i.MX6 on Development Kit with CSO0 and CSI1 as phyCAM-P or phyCAM-S+
  * phyFLEX-i.MX6 on SUBRA Kit with CSO0 and CSI1 as phyCAM-S+
- phyCORE-i.MX6 with CSO0 and CSI1 as parallel
  * phyCORE-i.MX6 on MIRA Kit with CSO0 as phyCAM-S+
- phyCARD-i.MX6 with CSO0 as LVDS
  * phyCARD-i.MX6 on Development Kit with CSO0 as phyCAM-S+

The BSP includes drivers to support connected cameras. The drivers are compatible
with v4l2 and the gstreamer scripts give examples of the usage and functionality.
  
camera typ (defaults)
=====================
phyFLEX (KIT):
- of_camera_selection -p 0 -b phyCAM-P -a 0x48 VM-011-COL

SUBRA (KIT):
- of_camera_selection -p 0 -b phyCAM-S+ -a 0x48 VM-010-COL

phyCARD (Kit):
- of_camera_selection -p 0 -b phyCAM-S+ -a 0x48 VM-010-BW

phyCORE (Kit):
- of_camera_selection -p 0 -b phyCAM-S+ -a 0x48 VM-010-BW

set new camera i2c adress or new camera typ
===========================================
For use the camera with more i2c adress or added a new camera, you have to compile the image new.
See instruction manual for YOCTO-BSPs.


***************************
First Steps
***************************
1) Setup config-expansions, for the connected camera (only at first start necessary).

Depending on the camera interface there has to be set a corresponding entry in the
/env/config-expansions file of the bootloader Barebox.
To change the device-tree use the Barebox environment:
- 'cd env' <enter>
- 'edit config-expansions' <enter>
For changes between camera_interface-typ and camera-parameter, the correct parameters must be set to CSIx.

of_camera_selection  -p <csi_port> -b <csiX_cam_bus_type> -a <csiX_cam_i2c_address> <cam_type>
- csi_port = [0,1]
- csix_cam_bus_type = [phyCAM-P, phyCAM-S+]
- csix_cam_i2c_address = [0x41-0x5D] depend of camera typ/setings
- csix_cam_type = [VM-006, VM-008, VM-009, VM-010-BW, VM-010-COL, VM-011-BW, VM-011-COL, VM-012-BW, VM-012-COL]

Example: VM-010-BW-LVD with i2C-address 0x48 on CSI0 (Camera_0) port
[of_camera_selection -p 0 -b phyCAM-S+ -a 0x48 VM-010-BW]

Note: See "phyCAM_with_phy<TYP>-iMX6_Getting_Started.pdf" for more details.
      On link "ftp://ftp.phytec.de/pub/ImageProcessing/".

After changing the settings with the editor
===========================================
- close the editor (CTRL D) 
- type 'saveenv' <enter> to save
- restart PHYTEC modul


2) Check the jumper settings, read "hardware manual" (only for change the defaults necessary).


3) Disable QT-Demo (only at first start necessary).
   - after login
   - change in the directory  /gstreamer_examples/.. -> cd gstreamer_examples <ENTER>
   - start remove_qt_demo -> ./remove_qt_demo <ENTER>
   - start reboot -> reboot <ENTER>


4) Start gstreamer Demos
   - after login
   - change in the directory  /gstreamer_examples/.. -> cd gstreamer_examples <ENTER>
   - start "bwcam-fbdev_640x480.sh" or "colcam-fbdev_640x480.sh" (depend on your camera type)
   - for more camera type examples, go in camera sensor type subdirectories
     (VM-006 -> mt9m001, VM-008 -> tw9910, VM-009 -> mt9m131, VM-010 -> mt9v024, VM-011 -> mt9p031)

For more informations see link "ftp://ftp.phytec.de/pub/ImageProcessing/"