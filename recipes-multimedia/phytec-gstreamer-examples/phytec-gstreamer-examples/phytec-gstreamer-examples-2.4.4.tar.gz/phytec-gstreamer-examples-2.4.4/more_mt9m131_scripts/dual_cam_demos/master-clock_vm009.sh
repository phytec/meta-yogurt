#!/bin/sh

CAM_I2C_ADRESS_0="48"
CAM_I2C_ADRESS_1="5d"
CAM_DEVICE_0=$(media-ctl -e "mt9m111 2-00$CAM_I2C_ADRESS_0")
CAM_DEVICE_1=$(media-ctl -e "mt9m111 2-00$CAM_I2C_ADRESS_1")
echo "CAM_DEVICE_0 = $CAM_DEVICE_0"
echo "CAM_DEVICE_1 = $CAM_DEVICE_1"
echo ""

echo "select Masterclock for both VM-009"
echo "it is necessary for right work of these cameras"
echo "==============================================="
echo "0 = VM-009      at 54,0MHz (phyCAM-P)"
echo "1 = VM-009-LVDS at 36,0MHz (phyCAM-S)"
read MASTERCLOCK
echo "Your select = $MASTERCLOCK"
case $MASTERCLOCK in
  "0") v4l2-ctl -d $CAM_DEVICE_0 --set-ctrl=x_pixel_rate=54000000; v4l2-ctl -d $CAM_DEVICE_1 --set-ctrl=x_pixel_rate=54000000;;
  "1") v4l2-ctl -d $CAM_DEVICE_0 --set-ctrl=x_pixel_rate=36000000; v4l2-ctl -d $CAM_DEVICE_1 --set-ctrl=x_pixel_rate=36000000;;
  *) v4l2-ctl -d $CAM_DEVICE_0 --set-ctrl=x_pixel_rate=36000000;
esac

