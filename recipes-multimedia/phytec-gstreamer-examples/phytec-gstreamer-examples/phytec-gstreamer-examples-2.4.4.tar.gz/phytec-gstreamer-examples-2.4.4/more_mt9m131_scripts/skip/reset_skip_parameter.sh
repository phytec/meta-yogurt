#!/bin/sh
. `dirname $0`/../../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo "set skip value via v4l2-ctl to 0"
v4l2-ctl -d $CAM_DEVICE --set-ctrl=skip_x=0
v4l2-ctl -d $CAM_DEVICE --set-ctrl=skip_y=0

