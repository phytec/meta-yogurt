#!/bin/sh

echo ""
echo "This gstreamer version don't supported Y10 format, therefore use the c-example"
echo "change into path ...\v4l2_c-examples\..."
echo "start file mt9m001_bw_full_save-raw.sh with CAM_BW_FMT=\"Y10\" directive"
echo ""