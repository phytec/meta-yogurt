#!/bin/sh

echo ""
echo "This gstreamer version don't supported Y10 format, therefore use the c-example"
echo "change into path ...\v4l2_c-examples\..."
echo "start file mt9v024_bw_full_save-raw.sh with CAM_BW_FMT=\"Y10\" directive"
echo ""


#. `dirname $0`/../../func.sh

#init_dev
#[ $? -ne 0 ] && exit 1

#guess_param

#echo "starting gstreamer iin $CAM_COL_FORMAT Source as BW Source..."
#echo "read $SENSOR_RES (offset x,y=$OFFSET_SENSOR) and write to file mt9v024_gray_10bit.raw"
#echo "======================================================================================"
#echo ""
#echo "configure IPU/VPU with media_control"
#echo "===================================="

#media-ctl -r
#media-ctl -V ''$CAM_ENTITY_NUMBER'0[fmt:'Y10'/'$SENSOR_RES'('$OFFSET_SENSOR')/'$SENSOR_RES']'
#media-ctl -V '"ipu0-csi0-sd":0[fmt:'Y10'/'$SENSOR_RES']'
#media-ctl -V '"ipu0-csi0-sd":1[fmt:'Y10'/'$SENSOR_RES']'
#media-ctl -l '2:0 -> 1:0[1], 1:1 -> 2:0[1]'
#           Camera -> IPU0-CSI0-sd -> IPU0-CSI0-video (/dev/videoX)

#echo ""
#echo "start gstreamer"
#echo "==============="

#gst-launch-1.0 \
#	v4l2src num-buffers=$NUMBER_OF_PIC device=$IPU0_CSI0_DEVICE ! \
#	i2c file=`dirname $0`/../../register-settings-mt9v02x.txt show=0 dev=$CAM_DEVICE ! \
#	video/x-raw,format=GRAY10,depth=12$FRAME_SIZE ! \
#	multifilesink location=mt9v024_gray_10bit.raw
