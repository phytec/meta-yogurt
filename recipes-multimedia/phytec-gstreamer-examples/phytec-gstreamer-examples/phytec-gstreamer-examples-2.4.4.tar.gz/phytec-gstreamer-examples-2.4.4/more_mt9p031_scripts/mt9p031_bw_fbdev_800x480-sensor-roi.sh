#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo 0 > /sys/class/graphics/fbcon/cursor_blink

GRAB_RES="800x480"
FRAME_SIZE=",width=800,height=480"
OFFSET_SENSOR="912,786"

echo "starting gstreamer with $CAM_BW_FMT Source ..."
echo "read $FRAME_SIZE (ROI in center of pic) and write to framebuffer $GRAB_RES"
echo "=========================================================================="
echo ""
echo "configure IPU/VPU with media_control"
echo "===================================="

media-ctl -r
media-ctl -V ''$CAM_ENTITY_NUMBER'0[fmt:'$CAM_BW_FMT'/'$GRAB_RES'('$OFFSET_SENSOR')/'$GRAB_RES']'
media-ctl -V '"ipu0-csi0-sd":0[fmt:Y8/'$GRAB_RES']'
media-ctl -V '"ipu0-csi0-sd":1[fmt:Y8/'$GRAB_RES']'
#            Camera -> ColShifter -> IPU0-CSI0 -> Out   

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 \
	v4l2src device=$IPU0_CSI0_DEVICE ! \
	i2c file=`dirname $0`/../register-settings-mt9p031.txt show=0 dev=$CAM_DEVICE ! \
	video/x-raw,format=GRAY8,depth=8$FRAME_SIZE ! \
	videoconvert ! \
	queue ! kmssink driver-name="imx-drm" scale=false sync=false
	#fbdevsink sync=false


echo 1 > /sys/class/graphics/fbcon/cursor_blink