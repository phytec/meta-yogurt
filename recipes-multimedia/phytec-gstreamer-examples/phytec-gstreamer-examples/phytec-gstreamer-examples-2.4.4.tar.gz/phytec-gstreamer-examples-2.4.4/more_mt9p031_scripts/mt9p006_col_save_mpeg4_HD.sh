#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

H264_ENC_VIDEONUMBER=`gst-inspect-1.0  | grep 264enc | awk '{print $2}'`
H264_ENC_VIDEONUMBER="${H264_ENC_VIDEONUMBER%?}"
echo "ENCODER Number = $H264_ENC_VIDEONUMBER"

echo "=============================================================================="
echo "starting gstreamer with $COL_FORMAT Source ..."
echo "read 1280x720, convert bayer2rgb, use i.MX6 vpu mpeg-4/H264 codec and write in col_capture.avi"
echo "=============================================================================================="
echo ""
echo "configure IPU/VPU with media_control"
echo "===================================="

media-ctl -r
media-ctl -V ''$CAM_ENTITY_NUMBER'0[fmt:'$CAM_COL_FMT'/1280x720 (16,54)/2560x1440]'
media-ctl -V '"ipu0-csi0-sd":0[fmt:'$CAM_COL_FMT'/1280x720]'
media-ctl -V '"ipu0-csi0-sd":1[fmt:'$CAM_COL_FMT'/1280x720]'
#           Camera -> IPU0-CSI0-sd -> IPU0-CSI0-video (/dev/videoX)   

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 \
	v4l2src device=$IPU0_CSI0_DEVICE ! \
	i2c file=`dirname $0`/../register-settings-mt9p031.txt show=0 dev=$CAM_DEVICE ! \
	video/x-$COL_FORMAT,depth=8,width=1280,height=720,framerate=25/1 ! \
	bayer2rgbneon ! \
	queue ! videoconvert ! $H264_ENC_VIDEONUMBER ! h264parse ! matroskamux ! \
	filesink location=col_capture.avi
	
echo "For show the saved stream, use VLC-Player"
echo ""
echo "if v4l2videoxh264enc not found, please update the gstreamer cache, type:"
echo "> rm $HOME/.cache/gstreamer-1.0/registry*"
echo "> gst-inspect-1.0"
echo ""