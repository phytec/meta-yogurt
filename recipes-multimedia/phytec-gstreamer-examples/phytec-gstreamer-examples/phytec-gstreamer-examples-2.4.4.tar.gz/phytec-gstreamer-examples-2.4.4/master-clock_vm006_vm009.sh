#!/bin/sh
. `dirname $0`/func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo "select Masterclock for VM-006 and VM-009"
echo "it is necessary for right work of these cameras"
echo "==============================================="
echo "0 = VM-006      at 43,2MHz (phyCAM-P)"
echo "1 = VM-006-LVDS at 36,0MHz (phyCAM-S)"
echo "2 = VM-009      at 54,0MHz (phyCAM-P)"
echo "3 = VM-009-LVDS at 36,0MHz (phyCAM-S)"
read MASTERCLOCK
echo "Your select = $MASTERCLOCK"
case $MASTERCLOCK in
  "0") v4l2-ctl -d $IPU0_CSI0_DEVICE --set-ctrl=link_frequency=1;;
  "1") v4l2-ctl -d $IPU0_CSI0_DEVICE --set-ctrl=link_frequency=0;;
  "2") v4l2-ctl -d $CAM_DEVICE --set-ctrl=x_pixel_rate=54000000;;
  "3") v4l2-ctl -d $CAM_DEVICE --set-ctrl=x_pixel_rate=36000000;;
  *) v4l2-ctl -d $IPU0_CSI0_DEVICE --set-ctrl=link_frequency=0;
esac

