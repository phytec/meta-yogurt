#!/bin/sh
. `dirname $0`/../../func.sh

echo 0 > /sys/class/graphics/fbcon/cursor_blink

CAM_I2C_ADRESS_0="48"
CAM_I2C_ADRESS_1="4c"
IPU0_CSI0_DEVICE=$(media-ctl -e "ipu0-csi0-video")
IPU1_CSI1_DEVICE=$(media-ctl -e "ipu1-csi1-video")
CAM_DEVICE_0=$(media-ctl -e "vm012@$CAM_I2C_ADRESS_0")
CAM_DEVICE_1=$(media-ctl -e "vm012@$CAM_I2C_ADRESS_1")
CAM_ENTITY_NUMBER_0=`media-ctl -p | grep " vm012@$CAM_I2C_ADRESS_0" | awk '{print $3}'`
CAM_ENTITY_NUMBER_1=`media-ctl -p | grep " vm012@$CAM_I2C_ADRESS_1" | awk '{print $3}'`

echo ""
echo "IPU0_CSI0_DEVICE = $IPU0_CSI0_DEVICE"
echo "IPU1_CSI1_DEVICE = $IPU1_CSI1_DEVICE"
echo "CAM_DEVICE_0 = $CAM_DEVICE_0"
echo "CAM_DEVICE_1 = $CAM_DEVICE_1"
echo "CAM_ENTITY_NUMBER_0 = $CAM_ENTITY_NUMBER_0"
echo "CAM_ENTITY_NUMBER_1 = $CAM_ENTITY_NUMBER_1"
echo ""


echo "starting gstreamer with two GRAY Sources ..."
echo "read camera_0 from CSI0 and camera_1 from CSI1 with 640 x 512 (skip)"
echo "scale both streams to 400x320 Pixel and write side by side into same framebuffer"
echo "================================================================================"
echo ""
echo "configure IPU/VPU with media_control"
echo "===================================="

media-ctl -r
v4l2-ctl -d $IPU0_CSI0_DEVICE -c subsampling=1
media-ctl -V ''$CAM_ENTITY_NUMBER_0'0[fmt:Y8/640x512 crop:(0,0)/640x512]'
media-ctl -V '"ipu0-csi0-sd":0[fmt:Y8/640x512]'
media-ctl -V '"ipu0-csi0-sd":1[fmt:Y8/640x512]'
#           Camera -> IPU0-CSI0-sd -> IPU0-CSI0-video (/dev/videoX)   

v4l2-ctl -d $IPU1_CSI1_DEVICE -c subsampling=1
media-ctl -V ''$CAM_ENTITY_NUMBER_1'0[fmt:Y8/640x512 (0,0)/640x512]'
media-ctl -V '"ipu1-csi1-sd":0[fmt:Y8/640x512]'
media-ctl -V '"ipu1-csi1-sd":1[fmt:Y8/640x512]'
#           Camera -> IPU1-CSI1-sd -> IPU1-CSI1-video (/dev/videoX)   


echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 videomixer name=mix  sink_0::xpos=0 sink_0::ypos=0 sink_1::xpos=400 sink_1::ypos=0 ! videoconvert ! queue ! kmssink driver-name="imx-drm" scale=false sync=false \
   v4l2src device=$IPU0_CSI0_DEVICE ! i2c addr=0x$CAM_I2C_ADRESS_0 file=`dirname $0`/../../register-settings-vita1300.txt show=0 dev=$CAM_DEVICE_0 ! \
   video/x-raw,format=GRAY8,width=640,height=512,framerate=25/1 ! vita1300_remapper mode=1 passthrough=false ! videoscale ! video/x-raw,format=GRAY8,width=400,height=320 ! \
   videoconvert ! queue ! mix. \
   v4l2src device=$IPU1_CSI1_DEVICE ! i2c addr=0x$CAM_I2C_ADRESS_1 file=`dirname $0`/../../register-settings-vita1300.txt show=0 dev=$CAM_DEVICE_1 ! \
   video/x-raw,format=GRAY8,width=640,height=512,framerate=25/1 ! vita1300_remapper mode=1 passthrough=false ! videoscale ! video/x-raw,format=GRAY8,width=400,height=320 ! \
   videoconvert ! queue ! mix. 


#gst-launch-1.0 \
#	v4l2src device=$IPU0_CSI0_DEVICE ! \
#	i2c addr=0x$CAM_I2C_ADRESS_0 file=`dirname $0`/../../register-settings-vita1300.txt show=0 dev=$CAM_DEVICE_0 ! \
#	video/x-raw,format=GRAY8,depth=8,width=640,height=512 ! \
#	vita1300_remapper mode=1 passthrough=false ! \
#	videoscale ! \
#	video/x-raw,format=GRAY8,width=640,height=480 ! \
#	videoconvert ! \
#	kmssink driver-name="imx-drm" scale=false sync=false	
#	fbdevsink sync=false
	
#gst-launch-1.0 \
#	v4l2src device=$IPU1_CSI1_DEVICE ! \
#	i2c addr=0x$CAM_I2C_ADRESS_1 file=`dirname $0`/../../register-settings-vita1300.txt show=0 dev=$CAM_DEVICE_1 ! \
#	video/x-raw,format=GRAY8,depth=8,width=640,height=512 ! \
#	vita1300_remapper mode=1 passthrough=false ! \
#	videoscale ! \
#	video/x-raw,format=GRAY8,width=640,height=480 ! \
#	videoconvert ! \
#	kmssink driver-name="imx-drm" scale=false sync=false	
#	fbdevsink sync=false
	
echo 1 > /sys/class/graphics/fbcon/cursor_blink
 