#!/bin/sh
. `dirname $0`/../func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

echo 0 > /sys/class/graphics/fbcon/cursor_blink

echo "select resolution"
echo "================="
echo "1 = 1280 x 1024 Fullframe (with gstreamer scaler artefacts)"
echo "2 = 1280 x 960 Frame (offset via media-ctl crop-parameter)"
echo "3 = 640 x 480 VGA with sensor-skip-mode(skip 640x512, set via v4l2-ctl)"
echo "4 = 800 x 480 WVGA with sensor-roi-mode (offset via media-ctl crop-parameter)"
read RESOLUTION
echo "Your select = $RESOLUTION"
case $RESOLUTION in
  "1") GRAB_RES="1280x1024"; FRAME_SIZE=",width=1280,height=1024"; SCALE_SIZE=",width=600,height=480"; OFFSET_SENSOR="0,0"; SUBSAMPLING="0"; REMAPPER_MODE="mode=0" ;;
  "2") GRAB_RES="1280x960"; FRAME_SIZE=",width=1280,height=960"; SCALE_SIZE=",width=640,height=480"; OFFSET_SENSOR="0,32"; SUBSAMPLING="0"; REMAPPER_MODE="mode=0" ;;
  "3") GRAB_RES="640x512"; FRAME_SIZE=",width=640,height=512"; SCALE_SIZE=",width=640,height=480"; OFFSET_SENSOR="0,0"; SUBSAMPLING="1"; REMAPPER_MODE="mode=2" ;;
  "4") GRAB_RES="800x480"; FRAME_SIZE=",width=800,height=480"; SCALE_SIZE=",width=800,height=480"; OFFSET_SENSOR="240,272"; SUBSAMPLING="0"; REMAPPER_MODE="mode=0" ;;
  *) GRAB_RES="1280x1024"; FRAME_SIZE=",width=1280,height=1024"; SCALE_SIZE=",width=640,height=480"; OFFSET_SENSOR="0,0"; SUBSAMPLING="0"; REMAPPER_MODE="mode=0" ;;
esac

echo "starting gstreamer with $CAM_BW_FMT Source ..."
echo "read $FRAME_SIZE (offset x,y=$OFFSET_SENSOR) and write scaled to framebuffer $SCALE_SIZE"
echo "=============================================================="
echo ""
echo "configure IPU/VPU with media_control"
echo "===================================="

media-ctl -r
v4l2-ctl -d $IPU0_CSI0_DEVICE -c subsampling=$SUBSAMPLING
media-ctl -V ''$CAM_ENTITY_NUMBER'0[fmt:'$CAM_COL_FMT'/'$GRAB_RES' crop:('$OFFSET_SENSOR')/'$GRAB_RES']'
media-ctl -V '"ipu0-csi0-sd":0[fmt:'$CAM_COL_FMT'/'$GRAB_RES']'
media-ctl -V '"ipu0-csi0-sd":1[fmt:'$CAM_COL_FMT'/'$GRAB_RES']'
#           Camera -> IPU0-CSI0-sd -> IPU0-CSI0-video (/dev/videoX) 

echo ""
echo "start gstreamer, break with ctl-C"
echo "================================="

gst-launch-1.0 \
	v4l2src device=$IPU0_CSI0_DEVICE ! \
	i2c file=`dirname $0`/../register-settings-vita1300.txt show=0 dev=$CAM_DEVICE ! \
	video/x-$COL_FORMAT,depth=8$FRAME_SIZE ! \
	vita1300_remapper $REMAPPER_MODE passthrough=false ! \
	bayer2rgbneon ! \
	video/x-raw$FRAME_SIZE ! \
	videoscale ! \
	video/x-raw$SCALE_SIZE ! \
	queue ! kmssink driver-name="imx-drm" scale=false sync=false	
#	fbdevsink sync=false

echo 1 > /sys/class/graphics/fbcon/cursor_blink
