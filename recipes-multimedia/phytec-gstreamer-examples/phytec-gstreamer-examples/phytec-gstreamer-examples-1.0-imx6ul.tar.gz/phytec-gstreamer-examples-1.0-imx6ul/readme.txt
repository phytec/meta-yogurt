**********************************************************
The following informations are for the PHYTEC BSP PD16.1.0
phyCORE-i.MX6UL
**********************************************************

The following phytec cameras are currently supported:
- VM-010-BW (@27MHz)
- VM-010-COL (@27MHz)

Additional phytec camera support is in progress.

Please pay attention to the maximum allowable frequencies.
Please read the the Manual L-740 "phyCAM-P / phyCAM-S".


********************************************************************
camera configuration
********************************************************************

The i.MX6UL moduls comes with one parallel interface for one phyCAM-P cameras.
- phyCORE-i.MX6UL with CSI as parallel (up to 10-Bit)
  * phyCORE-i.MX6UL on Development Kit with CSI as phyCAM-P

The BSP includes drivers to support connected phytec-cameras.

The drivers are compatible with v4l2 and the gstreamer scripts give examples of
the usage and functionality.
  
camera typ (defaults)
=====================
phyCORE-i.MX6UL (KIT):
VM-011-BW at i2c adress 0x48


set new camera i2c adress or new camera typ
===========================================
For use the camera with more i2c adress or added a new camera, you have to compile the image new.
See instruction manual for YOCTO-BSPs.


***************************
First Steps
***************************
1) Depending on the camera there has to be set a corresponding entry in the bootloader Barebox.
To change the device-tree use the Barebox environment:
At the moment you can only change between the col-versions of VM-010.

- type 'nv linux.bootargs.mt9v022="mt9v022.sensor_type=color"' <enter>, for color version
- type 'nv linux.bootargs.mt9v022="mt9v022.sensor_type=mono"' <enter>, for monochrome version
- type 'saveenv' <enter>
- type 'reset' <enter>

Note: See "phyCAM_with_phy<TYP>-iMX6_Getting_Started.pdf" for more details.
      On link "ftp://ftp.phytec.de/pub/ImageProcessing/".

2) Start gstreamer Demos
   - after login
   - change in the directory  /gstreamer_examples/.. -> cd gstreamer_examples <ENTER>
   - start "bwcam-fbdev_640x480.sh" or "colcam-fbdev_640x480.sh" (depend on your camera type)
   - for more camera type examples, go in camera sensor type subdirectories
     (VM-010 -> mt9v024)

For more informations see link "ftp://ftp.phytec.de/pub/ImageProcessing/"