For help of "save_raw_image" type 
> save_raw_image -h


Please use the following scripts for the corresponding phytec camera module:
VM-010-BW 	= mt9v02x_bw_full_save-raw.sh
VM-010-COL 	= mt9v02x_col_full_save-raw.sh

#Sourcen are located, in BSP pfad "...git clone git://git.phytec.de/bvtest/...".
#receipts are located, in BSP pfad "...sources/meta-yogurt/recipes-support/bvtest/...".


links of interest:
http://linuxtv.org/downloads/v4l-dvb-apis/v4l2grab-example.html 
http://linuxtv.org/downloads/v4l-dvb-apis/capture-example.html 
help under: 
http://linuxtv.org/downloads/v4l-dvb-apis/ 
