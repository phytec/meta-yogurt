#!/bin/sh
#check bootarg in config-file

. /usr/share/phytec-gstreamer-examples/func.sh

init_dev
[ $? -ne 0 ] && exit 1

guess_param

# Additional Settings
COL_FMT="Y8"
X_RES=752
Y_RES=480
REG_SET_FILE=/usr/share/phytec-gstreamer-examples/${REG_SET_FILE##*/}


echo "starting save_raw_image with GRAY Source ..."
echo "read $FRAME_SIZE and write to file $CAMERA"_"$COL_FMT"_"x.raw"
echo "================================================================"

save_raw_image -no_subdev -f $COL_FMT -res_x $X_RES -res_y $Y_RES -d $NUMBER_OF_PIC -r $REG_SET_FILE -n $CAMERA"_"$COL_FMT"_"

